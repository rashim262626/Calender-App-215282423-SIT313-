## AndroidDialer
google dialer for Android N

## Example screenshot below:
![github](https://raw.githubusercontent.com/geniusgithub/AndroidDialer/master/storage/m1.jpg "github") 
![github](https://github.com/geniusgithub/AndroidDialer/blob/master/storage/m2.jpg "github")  

##APK DOWNLOAD
* [AndroidDialer.apk](https://raw.githubusercontent.com/geniusgithub/AndroidDialer/master/storage/com.android.dialer.apk)

##LIB:
* com.android.support:appcompat
* com.android.support:appcompat:recycleview
* com.android.support:appcompat:cardview
* com.android.support:appcompat:design
* com.android.support:support-v13

##Run requirements
Android OS 5.0 and up

## Links
cnblog:[http://www.cnblogs.com/lance2016/](http://www.cnblogs.com/lance2016/p/6107376.html)
 
## Development
If you think this article useful Nepal , please pay attention to me<br />
Your support is my motivation, I will continue to strive to do better

