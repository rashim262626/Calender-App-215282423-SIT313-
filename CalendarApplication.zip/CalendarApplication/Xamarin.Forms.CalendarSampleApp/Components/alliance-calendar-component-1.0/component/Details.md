Alliance Calendar control provides a full calendar view for Android from v2.2 .

**Adding Alliance Calendar control to your Android app.**


```   <com.alliance.calendar.CustomCalendar         android:id="@+id/CalendarControl"
        android:layout_width="fill_parent"
        android:layout_height="fill_parent"/>                 
```


